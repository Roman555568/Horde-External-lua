ENT.Base = "npc_hordeext_kf_ai"
ENT.Type = "ai"

ENT.PrintName 		= "Crawler"
ENT.Instructions 	= "Click on the spawnicon to spawn it."
ENT.Category		= "npcs"

ENT.Spawnable = true
ENT.AdminOnly = false
VJ.AddNPC("Crawler","npc_hordeext_crawler", "Zombies")



