include('shared.lua')




killicon.Add( "npc_kfmod_crawler", "HUD/killicons/zed_claw", Color( 255, 255, 255, 255 ) )
killicon.Add( "#npc_kfmod_crawler", "HUD/killicons/zed_claw", Color( 255, 255, 255, 255 ) )