include("shared.lua")

function ENT:Draw()
	self:DrawModel()
end

function ENT:IsTranslucent()
	return true
end