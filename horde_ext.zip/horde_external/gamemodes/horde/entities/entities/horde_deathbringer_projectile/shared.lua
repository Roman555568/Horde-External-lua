ENT.Type = "anim"
ENT.PrintName = "Deathbringer Projectile"
ENT.Author = ""
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""
ENT.DoNotDuplicate = true
ENT.DisableDuplicator = true