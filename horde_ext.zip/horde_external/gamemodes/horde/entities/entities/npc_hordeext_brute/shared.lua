ENT.Base = "npc_hordeext_kf_ai"
ENT.Type = "ai"

ENT.Author = "ERROR"
ENT.Contact = ""
ENT.Information		= ""
ENT.Category		= "SNPCs"

ENT.Spawnable = false
ENT.AdminOnly = false


VJ.AddNPC("Brute","npc_hordeext_brute", "Zombies")

