AddCSLuaFile()

SWEP.PrintName = "Horde Medkit"
SWEP.Author = "robotboy655 & MaxOfS2D"
SWEP.Purpose = "Heal people with your primary attack, or yourself with the secondary."
SWEP.Category = "ArcCW - Horde" -- edit this if you like

SWEP.Slot = 5
SWEP.SlotPos = 3

SWEP.Spawnable = true

SWEP.ViewModel = Model( "models/weapons/c_medkit.mdl" )
SWEP.WorldModel = Model( "models/weapons/w_medkit.mdl" )
SWEP.ViewModelFOV = 54
SWEP.UseHands = true

SWEP.Primary.ClipSize = 100
SWEP.Primary.DefaultClip = 100
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.HealAmount = 100 -- Maximum heal amount per use
SWEP.MaxAmmo = 100 -- Maxumum ammo

local HealSound = Sound( "HealthKit.Touch" )
local DenySound = Sound( "WallHealth.Deny" )

function SWEP:Initialize()

	self:SetHoldType( "slam" )

end

if SERVER then
	function SWEP:StartRegenPoints(time)

		local timer_obj = self.Medkit_Ammo_Timer
		if !timer_obj then
			timer_obj = HORDE.Timers:New({
				linkwithent = self,
				timername = "medkit_ammo" .. self:EntIndex(),
				func = function(timerobj)
					if ( self:Clip1() < self.MaxAmmo ) then
						self:SetClip1( math.min( self:Clip1() + 4, self.MaxAmmo ) )
					else
						timerobj:Stop()
					end
				end,
				callfunconstart = true,
				delay = time / 25
			})
			self.Medkit_Ammo_Timer = timer_obj
			timer_obj:UpdateTimer()
		else
			timer_obj:SetDelay(time / 25)
			timer_obj:UpdateTimer()
		end
	end

	function SWEP:Horde_StartTimeStop()
		local owner = self:GetOwner()
		if self.Medkit_Ammo_Timer and owner != HORDE.TimeStop_Activator() then
			self.Medkit_Ammo_Timer:Stop()
		end
	end

	function SWEP:Horde_EndTimeStop()
		local owner = self:GetOwner()
		if self.Medkit_Ammo_Timer and owner != HORDE.TimeStop_Activator() then
			self.Medkit_Ammo_Timer:Start()
		end
	end
end

function SWEP:PrimaryAttack()

	if ( CLIENT ) then return end

	if ( self.Owner:IsPlayer() ) then
		self.Owner:LagCompensation( true )
	end

	local tr = util.TraceLine( {
		start = self.Owner:GetShootPos(),
		endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * 100,
		filter = self.Owner
	} )

	if ( self.Owner:IsPlayer() ) then
		self.Owner:LagCompensation( false )
	end

	local ent = tr.Entity

	local need = self.HealAmount
	if ( IsValid( ent ) ) then
		need = self.HealAmount
	else
		return
	end

	if self:Clip1() >= need && ( ent:IsPlayer() ) then

		self:TakePrimaryAmmo( need )

        local healinfo = HealInfo:New({amount = 20, healer = self.Owner, immediately = false})
        HORDE:OnPlayerHeal(ent, healinfo)
		ent:EmitSound( HealSound )

		self:SendWeaponAnim( ACT_VM_PRIMARYATTACK )

		self:SetNextPrimaryFire( CurTime() + self:SequenceDuration() + 0.5 )
		self.Owner:SetAnimation( PLAYER_ATTACK1 )

		-- Even though the viewmodel has looping IDLE anim at all times, we need this to make fire animation work in multiplayer
		timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 1, function() if ( IsValid( self ) ) then self:SendWeaponAnim( ACT_VM_IDLE ) end end )

		self:StartRegenPoints(2)

	else

		self.Owner:EmitSound( DenySound )
		self:SetNextPrimaryFire( CurTime() + .5 )

	end

end

function SWEP:SecondaryAttack()

	if ( CLIENT ) then return end

	local ent = self.Owner

	local need = self.HealAmount
	if ( IsValid( ent ) ) then need = self.HealAmount end

	if ( IsValid( ent ) && self:Clip1() >= need && ( ent:IsPlayer() or ent:GetClass() == "npc_vj_horde_antlion") ) then

		self:TakePrimaryAmmo( need )

        local healinfo = HealInfo:New({amount = 20, healer = self.Owner, immediately = false})
        if ent:IsPlayer() then
			HORDE:OnPlayerHeal(ent, healinfo)
		elseif ent:GetClass() == "npc_vj_horde_antlion" then
			HORDE:OnAntlionHeal(ent, healinfo)
		end
		ent:EmitSound( HealSound )

		self:SendWeaponAnim( ACT_VM_PRIMARYATTACK )

		self:SetNextSecondaryFire( CurTime() + self:SequenceDuration() + 0.5 )
		self.Owner:SetAnimation( PLAYER_ATTACK1 )

		timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 1, function() if ( IsValid( self ) ) then self:SendWeaponAnim( ACT_VM_IDLE ) end end )

		self:StartRegenPoints(5)

	else

		ent:EmitSound( DenySound )
		self:SetNextSecondaryFire( CurTime() + .5 )

	end

end

function SWEP:OnRemove()

	timer.Stop( "medkit_ammo" .. self:EntIndex() )
	timer.Stop( "weapon_idle" .. self:EntIndex() )

end

function SWEP:Holster()

	timer.Stop( "weapon_idle" .. self:EntIndex() )

	return true

end

function SWEP:CustomAmmoDisplay()

	self.AmmoDisplay = self.AmmoDisplay or {}
	self.AmmoDisplay.Draw = true
	self.AmmoDisplay.PrimaryClip = self:Clip1()

	return self.AmmoDisplay

end

--SWEP.CantDropWep = true