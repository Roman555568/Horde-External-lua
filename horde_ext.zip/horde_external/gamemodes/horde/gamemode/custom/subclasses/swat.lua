SUBCLASS.PrintName = HORDE.Class_SWAT or "SWAT"
SUBCLASS.Description = [[
SWAT main class.]]
SUBCLASS.Perks = {}
SUBCLASS.Icon = "SWAT.png"