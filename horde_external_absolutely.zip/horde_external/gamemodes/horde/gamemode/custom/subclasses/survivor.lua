SUBCLASS.PrintName = HORDE.Class_Survivor
SUBCLASS.Description = [[
Survivor main class.]]
SUBCLASS.Perks = {}
SUBCLASS.Icon = "Survivor.png"
