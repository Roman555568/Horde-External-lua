CreateConVar("horde_enable_slomo", 1, {FCVAR_SERVER_CAN_EXECUTE, FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Enabled Slomo.")
CreateConVar("horde_waves_type", 1, {FCVAR_SERVER_CAN_EXECUTE, FCVAR_ARCHIVE, FCVAR_REPLICATED}, "1 - 10 waves, 2 - 7 waves, 3 - 4 waves.")
