game.AddParticles( "particles/Recluse_fx.pcf" )
game.AddParticles( "particles/Recluse_fx2.pcf" )

PrecacheParticleSystem( "Recluse_Flash" )
PrecacheParticleSystem( "recluse_tracer" )



