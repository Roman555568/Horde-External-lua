HORDE:Sound_AddFireSound("tdon_rm22.Single", "weapons/tdon/rm22/weap_dlcar_mech_01.wav", false, ")" )
HORDE:Sound_AddWeaponSound("tdon_rm22.Magout", "weapons/tdon/rm22/wpfoly_rm22_reload_clipout.wav")
HORDE:Sound_AddWeaponSound("tdon_rm22.Magin", "weapons/tdon/rm22/wpfoly_rm22_reload_clipin.wav")
HORDE:Sound_AddWeaponSound("tdon_rm22.Pull", "weapons/tdon/rm22/wpfoly_rm22_reload_chamber.wav")
