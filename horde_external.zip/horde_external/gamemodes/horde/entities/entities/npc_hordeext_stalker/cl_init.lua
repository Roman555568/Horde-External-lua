include('shared.lua')


killicon.Add( "npc_kfmod_stalker", "HUD/killicons/zed_claw", Color( 255, 255, 255, 255 ) )
killicon.Add( "#npc_kfmod_stalker", "HUD/killicons/zed_claw", Color( 255, 255, 255, 255 ) )