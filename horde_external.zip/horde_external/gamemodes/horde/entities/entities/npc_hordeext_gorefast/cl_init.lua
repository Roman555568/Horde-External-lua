include('shared.lua')




killicon.Add( "npc_kfmod_gorefast", "HUD/killicons/gorefast_sword", Color( 255, 255, 255, 255 ) )
killicon.Add( "#npc_kfmod_gorefast", "HUD/killicons/gorefast_sword", Color( 255, 255, 255, 255 ) )