include('shared.lua')




killicon.Add( "npc_kfmod_bloat", "HUD/killicons/bloat_backsword", Color( 255, 255, 255, 255 ) )
killicon.Add( "#npc_kfmod_bloat", "HUD/killicons/bloat_backsword", Color( 255, 255, 255, 255 ) )